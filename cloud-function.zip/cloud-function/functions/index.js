const functions = require("firebase-functions");
const {
  reply,
  postToDialogflow,
  getLineContent,
} = require("./module/lineModule");
const {
  createReport,
  getImageUrl,
  addNotification,
  getSubcribeByID,
  getUserByID,
  sendToDeviceNotification,
  getOwnerRoomNotificationData,
  getCommenNotificationData,
  addLinePic,
  sendMailMsg,
  sendSuperMail,
  createLog,
  updateReportStatus,
  getManageWorkByID,
  commentReport,
  findEmailNotifyStaff,
} = require("./module/firebaseModule");
const {
  postToSheet,
  statusToText,
  typeToText,
  placeCodeToText,
} = require("./module/sheetModule");

exports.LineAdapter = functions
  // .region("asia-northeast1")
  .region("asia-southeast2")
  .https.onRequest((req, res) => {
    if (req.method === "POST") {
      let event = req.body.events[0];
      if (event.type === "message" && event.message.type === "text") {
        postToDialogflow(req);
      } else if (
        event.type === "message" &&
        (event.message.type === "file" || event.message.type === "image")
      ) {
        let userId = event.source.userId;
        let timestamp = event.timestamp;
        return getLineContent(event.message.id, timestamp, userId).then(
          (filename) => {
            return addLinePic({
              lineID: userId,
              timestamp: timestamp,
              filename: filename,
            });
          }
        );
      } else {
        reply(req);
      }
    }
    return res.status(200).send(req.method);
  });

// eslint-disable-next-line promise/catch-or-return
// getLineContent(12402657762724, 1595995376545).then(r => console.log(r))
exports.ACRAAdapter = functions
  // .region("asia-northeast1")
  .region("asia-southeast2")
  .https.onRequest((req, res) => {
    if (req.method === "POST") {
      createLog(req.body);
    }
    return res.status(200).send(req.method);
  });

exports.SendNewReportToSheet = functions //plz refactor this
  // .region("asia-northeast1")
  .region("asia-southeast2")
  .firestore.document("reports/{reportId}")
  .onCreate((snap, context) => {
    const newValue = snap.data();

    return getImageUrl(newValue.pictures, []).then(async (urls) => {
      let creator = (await getUserByID(newValue.creatorID)).data();
      postToSheet({
        detail: newValue.detail,
        building: placeCodeToText(newValue.placeCode),
        location: newValue.room,
        category: typeToText(newValue.type),
        status: statusToText(newValue.status),
        takecareBy: newValue.takecareBy ? newValue.takecareBy:"-",
        lastModified: newValue.lastModified ? newValue.lastModified:"-",
        rating: newValue.rating ? newValue.rating:"-",
        time: newValue.timestamp.toDate(), //edit VVVV plz
        // eslint-disable-next-line eqeqeq
        picURL: newValue.GDriveUrls ? newValue.GDriveUrls : urls.join("\n"),
        id: newValue.sid
          ? newValue.sid
          : creator.firstname + " " + creator.lastname, //todo
        reportID: context.params.reportId,
        action: "create",
      });
      return 0;
    });
  });

exports.SendUpdateToSheet = functions
  // .region("asia-northeast1")
  .region("asia-southeast2")
  .firestore.document("reports/{reportId}")
  .onUpdate((change, context) => {
    const data = change.after.data();
    console.log(data);
    return postToSheet({
      status:
        statusToText(data.status)
      ,
      takecareBy:  data.takecareBy,
      rating: data.rating,

      reportID: context.params.reportId,
      lastModified: data.lastModified.toDate().toUTCString(),
      action: "update",
    });
  });

exports.FormAdapter = functions
  // .region("asia-northeast1")
  .region("asia-southeast2")
  .https.onRequest((req, res) => {
    let data = req.body;
    if (data.action === "create") return createReport(req.body);
    else if (data.action === "update") return updateReportStatus(req.body);
    else return res.status(404);
  });

//merge old code here => https://docs.google.com/document/d/1DIzlHO4twcv1BNrX5Yvia6_vhxadOf0UIJq7N8fKn9E/edit?fbclid=IwAR2rTkHuwxlEcXIt1vwVATHvZu86UtOsYXbh4I58ECHMK6T5n-I70q4lL28
exports.sendStatusUpdateNotification = functions
  // .region("asia-northeast1")
  .region("asia-southeast2")
  .firestore.document("reports/{reportID}")
  .onUpdate((change, context) => {
    const reportID = context.params.reportID;
    const newData = change.after.data();
    const previousData = change.before.data();
    if (newData.status !== previousData.status) {
      const message =
        "ปัญหาที่คุณติดตามได้เปลี่ยนสถานะจาก '" +
        statusToText(previousData.status) +
        "' เป็น '" +
        statusToText(newData.status) +
        "'";
      const type = "status";
      // if (previousData.mail)
      //   sendSuperMail(previousData.mail, message, previousData);
      // sendMailMsg(previousData.mail, message, previousData);

      getSubcribeByID(reportID)
        .then((snapshot) => {
          return snapshot.forEach((doc) => {
            addNotification(
              reportID,
              doc.ref.parent.parent.id,
              message,
              type,
              ""
            );
          });
        })
        .catch((err) => {
          throw err;
        });

        if(newData.status === 4){
          const ratingmessage = "ปัญหาที่คุณแจ้งได้รับการแก้ไขเสร็จสิ้น กรุณาให้คะแนนความพึงพอใจ";
          addNotification(
            reportID,
            newData.creatorID,
            ratingmessage,
            type,
            ""
          );
        }
        
    }
  });

  exports.sendManageWorkNotification = functions
  // .region("asia-northeast1")
  .region("asia-southeast2")
  .firestore.document("reports/{reportID}")
  .onUpdate((change, context) => {
    const reportID = context.params.reportID;
    const newData = change.after.data();
    const previousData = change.before.data();
    if (newData.takecareBy !== null && newData.status === 1) {
      const message =
        "คุณได้รับมอบหมายงานดังกล่าว" 
      const type = "status";
      // if (previousData.mail)
      //   sendSuperMail(previousData.mail, message, previousData);
      // sendMailMsg(previousData.mail, message, previousData);
      
      addNotification(
            reportID,
            newData.takecareBy_id,
            message,
            type,
            ""
          );
  }
});
  

// exports.sendCommentNotification = functions
//   .region("asia-northeast1")
//   .firestore.document("reports/{reportID}/comments")
//   .onCreate((snap, context)=>{
//     const data = snap.data();
//     const comment = data.comment
//     const commenter = data.commenter
//     const reportID = context.params.reportID
//     return commentReport(data).then((result)=>{
//       const
//     })
//   })

exports.sendReportCreateNotification = functions
  // .region("asia-northeast1")
  .region("asia-southeast2")
  .firestore.document("reports/{reportID}")
  .onCreate((snap, context) => {
    const newReport = snap.data();
    return findEmailNotifyStaff(newReport).then((emails) => {
      for (let i = 0; i < emails.length; i++) {
        sendSuperMail(
          emails[i],
          "มีแจ้งเตือนปัญหาใหม่ที่คุณรับผิดชอบ",
          newReport
        );
      }
      return 0;
    });
  });

exports.sendNewCommentNotification = functions
  // .region("asia-northeast1")
  .region("asia-southeast2")
  .firestore.document("reports/{reportID}/comments/{commentID}")
  .onCreate((snap, context) => {
    const reportID = context.params.reportID;
    const commenter = snap.data().commenter;
    return getCommenNotificationData(reportID, commenter).then((result) => {
      const subscribe_snapshot = result[1];
      const userFirstName = result[0].data().firstname;
      const userLastName = result[0].data().lastname;
      const name = userFirstName + " " + userLastName;
      const message = name + " ได้แสดงความคิดเห็นปัญหาที่คุณติดตาม";
      const type = "comment";
      return subscribe_snapshot.forEach((doc) => {
        console.log(doc.id, "=>", doc.data());
        const subscriber_id = doc.ref.parent.parent.id;
        if (subscriber_id !== commenter)
          return addNotification(
            reportID,
            subscriber_id,
            message,
            type,
            commenter
          );
        return 0;
      });
    });
  });

exports.sendUserNotification = functions
  // .region("asia-northeast1")
  .region("asia-southeast2")
  .firestore.document("users/{uid}/notifications/{notificationId}")
  .onCreate((snap, context) => {
    const uid = context.params.uid;
    const notificationId = context.params.notificationId;
    const data = snap.data();

    var commenter = "";
    var click_action = "OPEN_OneReporActivity";
    if (data.type === "comment") {
      commenter = data.commenter;
      click_action = "OPEN_CommentActivity";
    }

    const notificationContent = {
      notification: {
        title: data.title,
        body: data.message,
        click_action: click_action,
      },
      data: {
        type: data.type,
        reportID: data.reportID,
        commenter: commenter,
      },
    };

    getUserByID(uid)
      .then((doc) => doc.data().tokenId)
      .then((tokenId) => sendToDeviceNotification(tokenId, notificationContent))
      .then((result) => console.log("Notification sent! ", data.message))
      .catch((err) => {
        throw err;
      });
  });

exports.sendOwnerRoomNotification = functions
  // .region("asia-northeast1")
  .region("asia-southeast2")
  .firestore.document("reports/{reportId}")
  .onCreate((snap, context) => {
    const reportID = context.params.reportId;
    const data = snap.data();
    const report_type = data.type;
    const creator = data.creatorID;
    const placeCode = data.placeCode;
    const room = data.room;
    return getOwnerRoomNotificationData(
      report_type,
      creator,
      placeCode,
      room
    ).then((result) => {
      const caretaker_snapshot = result[0];
      const userFirstName = result[1].data().firstname;
      const userLastName = result[1].data().lastname;
      const name = userFirstName + " " + userLastName;
      // var data;
      const room_snapshot = result[2];
      // const building_snapshot = result[3];
      
      var message = name + " ได้แจ้งปัญหาที่คุณรับผิดชอบ";
      var message2 = name + " ได้แจ้งปัญหาภายในห้องที่คุณรับผิดชอบ";
      var message3 = name + " ได้แจ้งปัญหาภายในอาคารที่คุณรับผิดชอบ";

      var type = "reportProblem";
      var type2 = "room";
      var type3 = "building";
      var data2;
      var data3;

    
      const check = String(room_snapshot.housekeeper_id);
      

      room_snapshot.forEach((doc) => {
        const check = String(doc.data().housekeeper_id);
        
      if (check !== "") {
        room_snapshot.forEach((doc) => {
          data2 = doc.data();
          console.log(doc.id, "=>", doc.data());

            addNotification(reportID, data2.housekeeper_id, message2, type2, "");
    
         
        });
      }

     else {

        caretaker_snapshot.forEach((doc) => {
          const temp = String(doc.data().takecareType);
          var tempsplit = temp.split(",");
          var i;
          for(i=0;i<tempsplit.length;i++){
            if(tempsplit[i] === report_type){  
            // data = doc.data();
              console.log(doc.id, "=>", doc.data());
    
              addNotification(reportID, doc.id, message, type, "");
              // sendSuperMail(doc.data().email, message, data);
              }

          }

         
        });
      }
       
  
       
      });

     
    //   if (!room_snapshot.housekeeper_id === "") {
    //     room_snapshot.forEach((doc) => {
    //       data2 = doc.data();
    //       console.log(doc.id, "=>", doc.data());

    //         addNotification(reportID, data2.housekeeper_id, message2, type2, "");
    
         
    //     });
    //   }

    //  else {

    //     caretaker_snapshot.forEach((doc) => {
    //       const temp = String(doc.data().takecareType);
    //       var tempsplit = temp.split(",");
    //       var i;
    //       for(i=0;i<tempsplit.length;i++){
    //         if(tempsplit[i] === report_type){  
    //         // data = doc.data();
    //           console.log(doc.id, "=>", doc.data());
    
    //           addNotification(reportID, doc.id, message, type, "");
    //           // sendSuperMail(doc.data().email, message, data);
    //           }

    //       }

         
    //     });
    //   }
      return;
    });
  });
