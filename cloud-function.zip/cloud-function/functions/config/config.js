const LINE_TOKEN = "RUfED4YgLzcrgWcHDkZq9Xqmr4Q89MlR3mkBAPsth4Qzt3Adnp9vzoW/rmUhZm8u+gOWnEKpXo01btXEP4fVRqCsDAoznMZ6DlHu7NCkAWCxB+5Tcng9hG0xSbE6DzZGYOck+iLBi1sUls2lMfhPDgdB04t89/1O/w1cDnyilFU="
const AGENT_ID = "20b0ccb4-be98-4a06-a66f-e250f1658326"
//for create report 
const FORM_ACC_ID = "zp1uXybvHbUKJ97nNcGdcMJNVzh2"
const FORM_DEFALT_pic_ID = "Report_picture_14092020_112510_8303502846819885020.jpg"
module.exports = {
    LINE_TOKEN,AGENT_ID,FORM_ACC_ID,FORM_DEFALT_pic_ID
}