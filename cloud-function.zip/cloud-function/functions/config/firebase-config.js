module.exports =  function () {
    var admin = require("firebase-admin");
    // var serviceAccount = require("./scitu-reports-firebase-adminsdk-1yogg-c477f23367.json"); test version
    var serviceAccount = require("./tusci-report-f52078cfddf.json")
    admin.initializeApp({
        credential: admin.credential.cert(serviceAccount),
        // storageBucket: "scitu-reports.appspot.com",   test version
        // databaseURL: "https://scitu-reports.firebaseio.com"  test version
        storageBucket: "tusci-report.appspot.com",
        databaseURL: "https://tusci-report.firebaseio.com"
        
    });
    return admin
}