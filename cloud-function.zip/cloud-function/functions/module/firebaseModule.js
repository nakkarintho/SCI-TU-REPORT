const initFirebaseAdmin = require("../config/firebase-config");
const admin = initFirebaseAdmin();
var bucket = admin.storage().bucket();

const fs = require("fs");
const {
  textToPlaceCode,
  textToType,
  placeCodeToText,
  TextsToStatus
} = require("./sheetModule");

const { template1 } = require("./mailTemplate");
const { FORM_ACC_ID, FORM_DEFALT_pic_ID } = require("../config/config");

const uploadImage = (path, fileName) => {
  return bucket
    .upload(path, { destination: "images/reports/" + fileName })
    .then(() => fs.unlinkSync(path));
};

const findEmailNotifyStaff = async (data) =>{
  const caretaker_query = await admin
  
  .firestore()
  .collection("users")
  .where("takecareType", "==", data.type)
  .get();
  
  let emails =[];

  caretaker_query.forEach(doc => {
    // console.log(doc.id, '=>', doc.data().email);
    emails.push(doc.data().email);
  });
  // console.log(emails);
  return emails;

};
// findEmailNotifyStaff({type: "ELECTRICS"})
// .then(r=> console.log(r))



const createReport = (data) => {
  return admin
    .firestore()
    .collection("reports")
    .add({
      creatorID: FORM_ACC_ID,
      detail: String(data.detail),
      geoPoint: new admin.firestore.GeoPoint(14.07421, 100.6074817), //todo
      pictures: data.URL
        ? data.URL.split(",").map((e) => "Form_" + e.split("id=")[1])
        : [FORM_DEFALT_pic_ID], //todo
      placeCode: textToPlaceCode(data.building),
      room: String(data.location),
      status: 1,
      timestamp: admin.firestore.Timestamp.fromDate(new Date(data.time)),
      type: textToType(data.category),
      sid: data.id,
      takecareBy: "xxxx",
      rating: data.rating,
      GDriveUrls: data.URL,
      mail: data.mail,
      lastModified: admin.firestore.Timestamp.fromDate(new Date(data.time))
    });
};

const updateReportStatus = (data) => {
  admin
    .firestore()
    .collection("reports")
    .doc(data.reportID)
    .update({ status: TextsToStatus(data.status), takecareBy: data.name });
  admin
    .firestore()
    .collection("reports")
    .doc(data.reportID)
    .collection("takecareBy")
    .add({
      staffname: data.name,
      date: admin.firestore.Timestamp.fromDate(new Date(data.time)),
    });
  return;
};



const addLinePic = (data) => {
  return admin
    .firestore()
    .collection("linePictures")
    .add({
      lineID: data.lineID,
      timestamp: admin.firestore.Timestamp.fromDate(new Date(data.timestamp)),
      filename: data.filename,
    });
};
const getImageUrl = (pictures, urls) => {
  if (pictures.length > 0) {
    return bucket
      .file("images/reports/" + pictures.pop())
      .getSignedUrl({
        action: "read",
        expires: "09-09-2491",
      })
      .then((link) => {
        urls.push(link[0]);
        return getImageUrl(pictures, urls);
      });
  } else {
    return urls;
  }
};

const addNotification = (reportID, uid, message, type, commenter) => {
  const timestamp = admin.firestore.FieldValue.serverTimestamp();
  var data = {
    title: "TUSCI Report",
    message: message,
    timestamp: timestamp,
    type: type,
    reportID: reportID,
    commenter: commenter,
  };
  //Increase new_noti number
  const user_doc = admin.firestore().collection("users").doc(uid);
  var transaction = admin
    .firestore()
    .runTransaction((t) => {
      return t.get(user_doc).then((doc) => {
        var noti = doc.data().new_noti + 1;
        return t.update(user_doc, { new_noti: noti });
      });
    })
    .then((result) => console.log("Transaction success!"))
    .catch((err) => {
      throw err;
    });

  //Add notification collection
  return admin
    .firestore()
    .collection("users")
    .doc(uid)
    .collection("notifications")
    .add(data)
    .then((ref) => {
      console.log("Added Notification with ID: ", ref.id);
      return ref.id;
    })
    .catch((err) => {
      throw err;
    });
};

//merge old code here
const getSubcribeByID = (reportID) =>
  admin
    .firestore()
    .collectionGroup("subscribe")
    .where("reportID", "==", reportID)
    .get();


const getManageWorkByID = (reportID) =>
  admin
  .firestore()
  .get();


const getUserByID = (uid) =>
  admin.firestore().collection("users").doc(uid).get();

const sendToDeviceNotification = (tokenId, notificationContent) =>
  admin.messaging().sendToDevice(tokenId, notificationContent);

const getOwnerRoomNotificationData = (
  report_type,
  creatorID,
  placeCode,
  room
) => {
  const caretaker_query = admin
    .firestore()
    .collection("users")
    //.where("takecareType", "==", report_type)
    .get();
  const user_query = admin.firestore().collection("users").doc(creatorID).get();

    const room_query = admin
    .firestore()
    .collection("buildings")
    .doc(placeCodeToString(placeCode))
    .collection("rooms")
    .where("name", "==", room)
    .get();
 
    //  const building_query = admin
    // .firestore()
    // .collection("buildings")
    // .doc(placeCodeToString(placeCode))
    // .collection("staff")
    // .doc(report_type)
    // .get(); 
  
   
  return Promise.all([caretaker_query, user_query, room_query]);
};

// const commentReport =(data)=>{
//   admin
//   .firestore()
//   .collection("reports")
//   .doc(data.reportID)
//   .collection("comments")
//   .add({comment: data.comment, 
//         commenter: getUserByName(data.uid),
//         reportID: data.reportID,
//         timestamp: admin.firestore.Timestamp.fromDate(new Date(data.time))
//       });
//       return;
// };

// const getUserByName = (data)=>{
//   var name = data.split(" ")
//   var firstname = name[0];
//   var lastname = name[1];

//   const user_query = admin
//   .firestore()
//   .collection("users")
//   .where("firstname", "==", firstname)
//   .where("lastname", "==", lastname)
//   .get();

//   if(user_query.empty){
//     console.log("Name is incorrect");
//     return;
//   }

//   user_query.forEach(doc => {
//    return doc.uid;
//   });
// }

const getCommenNotificationData = (reportID, commenter) => {
  const user_query = admin.firestore().collection("users").doc(commenter).get();
  const subscribe_query = admin
    .firestore()
    .collectionGroup("subscribe")
    .where("reportID", "==", reportID)
    .get();
  return Promise.all([user_query, subscribe_query]);
};

function placeCodeToString(code) {
  switch (code) {
    case 0:
      return "บร.2";

    case 1:
      return "บร.3";

    case 2:
      return "บร.4";

    case 3:
      return "บร.5";

    default:
      return "unknown";
    // code block
  }
}

//email sender function here
async function sendMailMsg(mail, msg, report) {
  let pics = await getImageUrl(report.pictures, []).then((urls) =>
    urls.map((url) => `<img src=${url}>`)
  );
  return admin
    .firestore()
    .collection("mail")
    .add({
      to: mail,
      message: {
        subject: "SCITUReport",
        html: `<h5>${msg}</h5><hr><p>${report.detail}</p><p>4${placeCodeToText(
          report.placeCode
        )} ${report.room}</p>${pics.join()}`,
      },
    })
    .then(() => console.log("Queued email for delivery!"));
}

async function sendSuperMail(mail, msg, report) {
  let pics = await getImageUrl(report.pictures, []).then((urls) =>
    urls.map((url) => `<img src=${url}>`)
  );
  return admin
    .firestore()
    .collection("mail")
    .add({
      to: mail,
      message: {
        subject: "SCITUReport",
        html: `<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
        <html xmlns="http://www.w3.org/1999/xhtml">
          <head>
            <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        
            <title>[SUBJECT]</title>
            <style type="text/css">
              body {
                padding-top: 0 !important;
                padding-bottom: 0 !important;
                padding-top: 0 !important;
                padding-bottom: 0 !important;
                margin: 0 !important;
                width: 100% !important;
                -webkit-text-size-adjust: 100% !important;
                -ms-text-size-adjust: 100% !important;
                -webkit-font-smoothing: antialiased !important;
              }
              .tableContent img {
                border: 0 !important;
                display: inline-block !important;
                outline: none !important;
              }
              a {
                color: #ffffff;
              }
        
              a.link1 {
                color: #c56d1d;
                text-decoration: none;
                font-size: 14px;
              }
        
              a.link2 {
                background: #ff9f4f;
                color: #ffffff;
                font-size: 15px;
                padding: 8px 12px;
                border-radius: 3px;
                -moz-border-radius: 3px;
                -webkit-border-radius: 3px;
                text-decoration: none;
              }
        
              a.link3 {
                text-decoration: none;
                color: #ffffff;
                font-size: 15px;
                background: #d611fc;
                padding: 8px 12px;
                border-radius: 3px;
                -moz-border-radius: 3px;
                -webkit-border-radius: 3px;
              }
              p {
                color: #555555;
                font-size: 14px;
                line-height: 22px;
              }
        
              p.special {
                line-height: 30px;
                font-size: 20px;
                color: #ffffff;
              }
        
              h2 {
                font-weight: normal;
                margin: 0;
                color: #000000;
                font-size: 22px;
              }
        
              a.link4 {
                font-size: 13px;
                line-height: 19px;
                color: #999999;
                text-decoration: none;
              }
        
              p,
              h1,
              ul,
              ol,
              li,
              div {
                margin: 0;
                padding: 0;
              }
        
              td,
              table {
                vertical-align: top;
              }
              td.middle {
                vertical-align: middle;
              }
            </style>
        
            <script type="colorScheme" class="swatch active">
              {
                  "name":"Default",
                  "bgBody":"EAEAEA",
                  "link":"ffffff",
                  "color":"555555",
                  "bgItem":"ffffff",
                  "title":"000000"
              }
            </script>
          </head>
          <body
            paddingwidth="0"
            paddingheight="0"
            bgcolor="#d1d3d4"
            style="
              padding-top: 0;
              padding-bottom: 0;
              padding-top: 0;
              padding-bottom: 0;
              background-repeat: repeat;
              width: 100% !important;
              -webkit-text-size-adjust: 100%;
              -ms-text-size-adjust: 100%;
              -webkit-font-smoothing: antialiased;
            "
            offset="0"
            toppadding="0"
            leftpadding="0"
          >
            <table
              width="100%"
              border="0"
              cellspacing="0"
              cellpadding="0"
              class="tableContent"
              align="center"
              bgcolor="#EAEAEA"
              style="font-family: helvetica, sans-serif;"
            >
              <!-- ================ header=============== -->
              <tbody>
                <tr>
                  <td height="20" bgcolor="#EAEAEA"></td>
                </tr>
                <tr>
                  <td align="center" class="bgBody">
                    <table
                      width="600"
                      border="0"
                      cellspacing="0"
                      cellpadding="0"
                      bgcolor="#FFFFFF"
                    >
                      <!-- ================ END header =============== -->
                      <tbody>
                        <tr>
                          <td>
                            <table
                              width="600"
                              border="0"
                              cellspacing="0"
                              cellpadding="0"
                            >
                              <tbody>
                                <tr>
                                  <td
                                    class="movableContentContainer bgItem"
                                    align="center"
                                  >
                                    <div class="movableContent">
                                      <table
                                        width="600"
                                        border="0"
                                        cellspacing="0"
                                        cellpadding="0"
                                      >
                                        <tbody>
                                          <tr>
                                            <td colspan="2" height="45"></td>
                                          </tr>
                                          <tr>
                                            <td width="20"></td>
                                            <td align="left">
                                              <div
                                                class="contentEditableContainer contentImageEditable"
                                              >
                                                <div class="contentEditable">
                                                  <img
                                                    src="https://cdn.discordapp.com/attachments/722808139518312508/747827000567136306/unknown.png"
                                                    alt="SCITUReport"
                                                  />
                                                </div>
                                              </div>
                                            </td>
                                          </tr>
                                          <tr>
                                            <td colspan="2" height="45"></td>
                                          </tr>
                                        </tbody>
                                      </table>
                                    </div>
        
                                    <!--  =========================== The body ===========================  -->
                                    <div class="movableContent">
                                      <table
                                        width="540"
                                        border="0"
                                        cellspacing="0"
                                        cellpadding="0"
                                      >
                                        <tbody>
                                          <tr>
                                            <td height="38"></td>
                                          </tr>
        
                                          <tr>
                                            <td height="12"></td>
                                          </tr>
                                          <tr>
                                            <td>
                                              <div
                                                class="contentEditableContainer contentTextEditable"
                                              >
                                                <div class="contentEditable">
                                                  <h3>${msg}</h3>
                                                  <hr>
                                                  <p>รายละเอียดปัญหา : ${report.detail}</p>
                                                  <p>สถานที่ : ${placeCodeToText(
                                                    report.placeCode
                                                  )} ${report.room}</p>
                                                  ${pics.join()}
                                                </div>
                                              </div>
                                            </td>
                                          </tr>
                                          <tr>
                                            <td height="37"></td>
                                          </tr>
                                          <tr>
                                            <td>
                                              <div
                                                style="border: 1px solid #ebe3e3;"
                                              ></div>
                                            </td>
                                          </tr>
                                        </tbody>
                                      </table>
                                    </div>
        
                                    <div class="movableContent">
                                      <table
                                        width="600"
                                        border="0"
                                        cellspacing="0"
                                        cellpadding="0"
                                      >
                                        <tbody>
                                          <tr>
                                            <td height="38"></td>
                                          </tr>
                                          <tr>
                                            <td>
                                              <table
                                                width="600"
                                                border="0"
                                                cellspacing="0"
                                                cellpadding="0"
                                                bgcolor="#fdf2ff"
                                              >
                                                <tbody>
                                                  <tr></tr>
                                                  <tr>
                                                    <td>
                                                      <div
                                                        class="contentEditableContainer contentTextEditable"
                                                      >
                                                        <div
                                                          class="contentEditable"
                                                        ></div>
                                                      </div>
                                                    </td>
                                                  </tr>
                                                  <tr></tr>
                                                  <tr>
                                                    <td>
                                                      <div
                                                        class="contentEditableContainer contentTextEditable"
                                                      >
                                                        <div
                                                          class="contentEditable"
                                                        ></div>
                                                      </div>
                                                    </td>
                                                  </tr>
                                                  <tr></tr>
                                                  <tr>
                                                    <td>
                                                      <div
                                                        class="contentEditableContainer contentTextEditable"
                                                      >
                                                        <div
                                                          class="contentEditable"
                                                        ></div>
                                                      </div>
                                                    </td>
                                                  </tr>
                                                  <tr></tr>
                                                </tbody>
                                              </table>
                                            </td>
                                          </tr>
                                        </tbody>
                                      </table>
                                    </div>
        
                                    <div class="movableContent">
                                      <table
                                        width="600"
                                        cellpadding="0"
                                        cellspacing="0"
                                        border="0"
                                        class="bgBody"
                                      >
                                        <tbody>
                                          <tr>
                                            <td
                                              height="180"
                                              bgcolor="#EAEAEA"
                                              align="center"
                                            >
                                              <table
                                                width="540"
                                                border="0"
                                                cellspacing="0"
                                                cellpadding="0"
                                              >
                                                <tbody>
                                                  <tr>
                                                    <td height="55"></td>
                                                  </tr>
                                                  <tr>
                                                    <td align="center">
                                                      <div
                                                        class="contentEditableContainer contentTextEditable"
                                                      >
                                                        <div class="contentEditable">
                                                          <p
                                                            style="
                                                              font-size: 13px;
                                                              color: #999999;
                                                              font-weight: bold;
                                                            "
                                                          >
                                                            Sent to [email] by
                                                            [CLIENTS.COMPANY_NAME] |
                                                            [CLIENTS.ADDRESS] |
                                                            [CLIENTS.PHONE]
                                                          </p>
                                                        </div>
                                                      </div>
                                                    </td>
                                                  </tr>
                                                  <tr>
                                                    <td height="10"></td>
                                                  </tr>
                                                  <tr>
                                                    <td
                                                      align="center"
                                                      style="
                                                        font-size: 13px;
                                                        color: #999999;
                                                      "
                                                    >
                                                      <div
                                                        class="contentEditableContainer contentTextEditable"
                                                      >
                                                        <div class="contentEditable">
                                                          <p>
                                                            <a
                                                              target="_blank"
                                                              href="file:///C:/Users/poap0/AppData/Local/Temp/Rar$EXa4260.41845/[CLIENTS.WEBSITE]"
                                                              style="color: #999999;"
                                                              class="link4"
                                                              >Home</a
                                                            >
                                                            |
                                                            <a
                                                              target="_blank"
                                                              href="file:///C:/Users/poap0/AppData/Local/Temp/Rar$EXa4260.41845/[SHOWEMAIL]"
                                                              class="link4"
                                                              style="color: #999999;"
                                                            >
                                                              Open in browser
                                                            </a>
                                                            |
                                                            <a
                                                              target="_blank"
                                                              href="file:///C:/Users/poap0/AppData/Local/Temp/Rar$EXa4260.41845/[UNSUBSCRIBE]"
                                                              style="color: #999999;"
                                                              class="link4"
                                                              >Unsubscribe</a
                                                            >
                                                          </p>
                                                        </div>
                                                      </div>
                                                    </td>
                                                  </tr>
                                                </tbody>
                                              </table>
                                            </td>
                                          </tr>
                                        </tbody>
                                      </table>
                                    </div>
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </td>
        
                  <!-- end footer-->
                </tr>
              </tbody>
            </table>
          </body>
        </html>`,
      },
    })
    .then(() => console.log("Queued email for delivery!"));
}

const createLog = (data) => {
  return admin.firestore().collection("log").add(data);
};
module.exports = {
  uploadImage,
  createReport,
  getImageUrl,
  addNotification,
  getSubcribeByID,
  getUserByID,
  sendToDeviceNotification,
  getOwnerRoomNotificationData,
  getCommenNotificationData,
  addLinePic,
  sendMailMsg,
  sendSuperMail,
  createLog,
  updateReportStatus,
  // commentReport,
  findEmailNotifyStaff

};
// eslint-disable-next-line promise/catch-or-return
// admin.firestore().collection("linePictures")
// .where('lineID', '==', 'Ufbea007cc00ce4f48b5749cc5a81268f')
// .where('timestamp', '<', admin.firestore.Timestamp.now())
// .get()
// .then(d => d.forEach((doc) => {
//     console.log(doc.id, ' => ', doc.data());
//   }))
// getImageUrl(["Form_1aWmbMnhMo9-NA4b1roxWleI1bqseQLuW"],[])
// .then(r=>console.log(r))