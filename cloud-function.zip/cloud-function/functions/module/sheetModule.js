const request = require("request-promise");

const postToSheet = (data) => {
    return request.post({
        uri: 'https://script.google.com/macros/s/AKfycbxxFjCpGw1wOFYB8ODZnFMaI2JOekG6gCYqFN0qvjmWDli8RYoq/exec',
        body: JSON.stringify(data)
    });
};

const statusToText = (status) => {
    switch (status) {
        case 1:
            return "เริ่มต้น"
        case 2:
            return "รับเรื่องแล้ว"
        case 3:
            return "กำลังดำเนินการ"
        case 4:
            return "เสร็จสิ้น"
        default:
            return "-"
    }
}
const TextsToStatus = (status) => {
    switch (status) {
        case "เริ่มต้น":
            return 1
        case "รับเรื่องแล้ว":
            return 2
        case "กำลังดำเนินการ":
            return 3
        case "เสร็จสิ้น":
            return 4
        default:
            return "-"
    }
}
const typeToText = (type) => {//todo
    switch (type) {
        case "ELECTRICS":
            return "ระบบไฟฟ้า"
        case "WATER":
            return "ระบบประปา"
        case "CONDITIONER":
            return "ระบบเครื่องปรับอากาศ"
        case "MATERIAL":
            return "วัสดุภายในห้อง"
        case "TECHNOLOGY":
            return "สื่อการเรียนการสอน"
        case "INTERNET":
            return "ไอทีและอินเทอร์เน็ต"
        case "BUILDING_ENVIRON":
            return "อาคารและสิ่งแวดล้อม"
        case "CLEAN_SECURITY":
            return "ความสะอาดและความปลอดภัย"
        case "TELEPHONE":
            return "ระบบโทรศัพท์"
        case "OTHERS":
            return "อื่นๆ"
        default:
            return "-"
    }
}

const placeCodeToText = (placeCode) => { //plz edit
    switch (placeCode) {
        case -1:
            return "ไม่สามารถระบุได้";
        case 0:
            return "บร.2";
        case 1:
            return "บร.3";
        case 2:
            return "บร.4";
        case 3:
            return "บร.5";
        case 4:
            return "ที่จอดรถบร.2";
        case 5:
            return "ที่จอดรถบร.5";
        case 6:
            return "โรงอาหาร";
        case 7:
            return "โคฟเวอร์เวย์ 1";
        case 8:
            return "โคฟเวอร์เวย์ 2";
        case 9:
            return "โคฟเวอร์เวย์ 3";
        case 10:
            return "ลานกว้างภาคคอม";
        case 11:
            return "ลานกว้างภาคสถิติ";
        case 14:
            return "วงเวียนบร.2";
        default:
            return "ไม่สามารถระบุได้";
    }
}

const textToPlaceCode = (text) => { //plz edit
    switch (text) {
        case "บร. 2":
            return 0;
        case "บร. 3":
            return 1;
        case "บร. 4":
            return 2;
        case "บร. 5":
            return 3;
        default:
            return -1;
    }
}

const textToType = (text) => {//todo
    switch (text) {
        case "ระบบไฟฟ้า":
            return "ELECTRICS";
        case "ระบบประปา":
            return "WATER";
        case "ระบบเครืองปรับอากาศ":
            return "CONDITIONER";
        case "วัสดุภายในห้อง":
            return "MATERIAL";
        case "สื่อการเรียนการสอน":
            return "TECHNOLOGY";
        case "ไอทีและอินเทอร์เน็ต":
            return "INTERNET";
        case "อาคารและสิ่งแวดล้อม":
            return "BUILDING_ENVIRON";
        case "ความสะอาดและความปลอดภัย":
            return " CLEAN_SECURITY";
        case "ระบบโทรศัพท์":
            return "TELEPHONE";

        case "อื่นๆ":
            return "OTHERS";
        default:
            return "";
    }
}
module.exports = {
    postToSheet, statusToText, typeToText, placeCodeToText, textToPlaceCode, textToType,TextsToStatus
}