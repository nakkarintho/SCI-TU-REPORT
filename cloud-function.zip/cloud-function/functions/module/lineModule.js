const { LINE_TOKEN, AGENT_ID } = require("../config/config")
const { uploadImage } = require("./firebaseModule")
const request = require("request-promise");
const os = require('os');
const path = require('path');
const fs = require("fs")

const reply = req => {
  return request.post({
    uri: 'https://api.line.me/v2/bot/message/reply',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer {' + LINE_TOKEN + '}'
    },
    body: JSON.stringify({
      replyToken: req.body.events[0].replyToken,
      messages: [
        {
          type: "text",
          text: JSON.stringify(req.body)
        }
      ]
    })
  });
};

const postToDialogflow = req => {
  req.headers.host = "bots.dialogflow.com";
  return request.post({
    uri: "https://bots.dialogflow.com/line/" + AGENT_ID + "/webhook",
    headers: req.headers,
    body: JSON.stringify(req.body)
  });
};

const getLineContent = (imageID, timestamp,userID) => {

  var options = {
    uri: 'https://api-data.line.me/v2/bot/message/' + imageID + '/content',
    headers: {
      'Authorization': 'Bearer {RUfED4YgLzcrgWcHDkZq9Xqmr4Q89MlR3mkBAPsth4Qzt3Adnp9vzoW/rmUhZm8u+gOWnEKpXo01btXEP4fVRqCsDAoznMZ6DlHu7NCkAWCxB+5Tcng9hG0xSbE6DzZGYOck+iLBi1sUls2lMfhPDgdB04t89/1O/w1cDnyilFU=}'
    },
    encoding: "binary",
    transform: (body, response, resolveWithFullResponse) => ({ 'headers': response.headers, 'data': body })
  };

  return request(options).then(
    (r) => {
      let type = r.headers['content-type'].split("/")[1]
      let fileName = "Line_" + timestamp + '.' + type
      let p = path.join(os.tmpdir(), fileName)
      let writeStream = fs.createWriteStream(p);
      writeStream.write(r.data, 'binary');
      writeStream.on('finish', () => {
        console.log('wrote all data to file');
      });
      
      writeStream.end(() => uploadImage(p,fileName));
      return fileName
    })
}

module.exports = {
  reply, postToDialogflow, getLineContent
}